import requests
import json

BASE_URL = "http://127.0.0.1:5002/recept"

def skapa_recept():
    namn = input("Ange receptnamn: ")
    ingredienser = input("Ange ingredienser (kommaseparerade): ").split(",")
    instruktioner = input("Ange instruktioner: ")

    data = {
        "Namn": namn,
        "Ingredienser": [ing.strip() for ing in ingredienser],
        "Instruktioner": instruktioner
    }

    response = requests.post(BASE_URL, json=data)
    if response.status_code == 201:
        print("Recept skapades:", json.dumps(response.json(), ensure_ascii=False, indent=4))
    else:
        print("Fel vid skapande av recept:", response.text)

def hamta_alla_recept():
    response = requests.get(BASE_URL)
    if response.status_code == 200:
        print("Alla recept:", json.dumps(response.json(), ensure_ascii=False, indent=4))
    else:
        print("Fel vid hämtning av recept:", response.text)

def hamta_recept():
    recept_id = input("Ange ID för receptet: ")
    response = requests.get(f"{BASE_URL}/{recept_id}")
    if response.status_code == 200:
        print("Recept hittades:", json.dumps(response.json(), ensure_ascii=False, indent=4))
    else:
        print("Recept hittades inte:", response.text)

def uppdatera_recept():
    recept_id = input("Ange ID för recept att uppdatera: ")
    namn = input("Ange nytt receptnamn: ")
    ingredienser = input("Ange nya ingredienser (kommaseparerade): ").split(",")
    instruktioner = input("Ange nya instruktioner: ")

    data = {
        "Namn": namn,
        "Ingredienser": [ing.strip() for ing in ingredienser],
        "Instruktioner": instruktioner
    }

    response = requests.put(f"{BASE_URL}/{recept_id}", json=data)
    if response.status_code == 200:
        print("Recept uppdaterades:", json.dumps(response.json(), ensure_ascii=False, indent=4))
    else:
        print("Fel vid uppdatering av recept:", response.text)

def ta_bort_recept():
    recept_id = input("Ange ID för recept att ta bort: ")
    response = requests.delete(f"{BASE_URL}/{recept_id}")
    if response.status_code == 200:
        print("Recept raderat:", response.json())
    else:
        print("Recept hittades inte:", response.text)

def main():
    while True:
        print("\nMeny:")
        print("1. Skapa nytt recept")
        print("2. Hämta alla recept")
        print("3. Hämta ett recept")
        print("4. Uppdatera ett recept")
        print("5. Ta bort ett recept")
        print("6. Avsluta")

        val = input("Välj ett alternativ: ")

        if val == "1":
            skapa_recept()
        elif val == "2":
            hamta_alla_recept()
        elif val == "3":
            hamta_recept()
        elif val == "4":
            uppdatera_recept()
        elif val == "5":
            ta_bort_recept()
        elif val == "6":
            print("Avslutar programmet.")
            break
        else:
            print("Ogiltigt val. Försök igen.")

if __name__ == "__main__":
    main()
