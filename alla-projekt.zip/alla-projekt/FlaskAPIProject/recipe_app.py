from flask import Flask, jsonify, request
import json

app = Flask(__name__)

# Ladda data för recept
def load_recipes_data():
    try:
        with open('recipes.json', 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# Spara data för recept
def save_recipes_data(data):
    with open('recipes.json', 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# CREATE (POST) för Recept
@app.route('/recept', methods=['POST'])
def skapa_recept():
    nytt_recept = request.json
    data = load_recipes_data()
    nytt_recept['id'] = len(data) + 1
    data.append(nytt_recept)
    save_recipes_data(data)
    return jsonify(nytt_recept), 201

# READ ALL (GET) för Recept
@app.route('/recept', methods=['GET'])
def hamta_alla_recept():
    data = load_recipes_data()
    return jsonify(data), 200

# READ ONE (GET) för Recept by ID
@app.route('/recept/<int:recept_id>', methods=['GET'])
def hamta_recept(recept_id):
    data = load_recipes_data()
    recept = next((x for x in data if x['id'] == recept_id), None)
    if recept:
        return jsonify(recept), 200
    else:
        return jsonify({'meddelande': 'Recept hittades inte'}), 404

# UPDATE (PUT) för Recept by ID
@app.route('/recept/<int:recept_id>', methods=['PUT'])
def uppdatera_recept(recept_id):
    data = load_recipes_data()
    recept = next((x for x in data if x['id'] == recept_id), None)
    if recept:
        uppdaterad_data = request.json
        recept.update(uppdaterad_data)
        save_recipes_data(data)
        return jsonify(recept), 200
    else:
        return jsonify({'meddelande': 'Recept hittades inte'}), 404
    
# Patch
@app.route('/recept/<int:recept_id>', methods=['PATCH'])
def partial_update_recept(recept_id):
    data = load_recipes_data()
    recept = next((x for x in data if x['id'] == recept_id), None)
    if recept:
        updated_data = request.json
        recept.update(updated_data)  # Uppdaterar endast de fält som skickas
        save_recipes_data(data)
        return jsonify(recept), 200
    else:
        return jsonify({'meddelande': 'Recept hittades inte'}), 404


# DELETE (DELETE) för Recept by ID
@app.route('/recept/<int:recept_id>', methods=['DELETE'])
def ta_bort_recept(recept_id):
    data = load_recipes_data()
    recept = next((x for x in data if x['id'] == recept_id), None)
    if recept:
        data.remove(recept)
        save_recipes_data(data)
        return jsonify({'meddelande': 'Recept raderat'}), 200
    else:
        return jsonify({'meddelande': 'Recept hittades inte'}), 404

# Starta Flask-server
if __name__ == '__main__':
    app.run(debug=True, port=5002)
