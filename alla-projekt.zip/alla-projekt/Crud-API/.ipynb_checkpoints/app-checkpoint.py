from flask import Flask, jsonify, request
import json

app = Flask(__name__)

# Här läser jag JSON - filen
def läs_från_fil(filnamn):
    try:
        with open(filnamn, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

# Funktion för att skriva till JSON-filen
def skriv_till_fil(filnamn, data):
    with open(filnamn, 'w') as f:
        json.dump(data, f, indent=4)

# Hämtar alla objekt
@app.route('/', methods=['GET'])
def hämta_alla():
    data = läs_från_fil('data.json')
    return jsonify(data), 200

# Hämta ett specifikt objekt
@app.route('/<int:id>', methods=['GET'])
def hämta_objekt(id):
    data = läs_från_fil('data.json')
    objekt = next((o for o in data if o['id'] == id), None)
    if objekt:
        return jsonify(objekt), 200
    return {"error": "Objekt hittades inte"}, 404

# För att skapa ett nytt objekt
@app.route('/', methods=['POST'])
def skapa_objekt():
    data = läs_från_fil('data.json')
    nytt_objekt = request.json
    if any(o['id'] == nytt_objekt['id'] for o in data):
        return {"error": "ID måste vara unikt"}, 400
    data.append(nytt_objekt)
    skriv_till_fil('data.json', data)
    return nytt_objekt, 201

# Uppdatera ett objekt
@app.route('/<int:id>', methods=['PUT'])
def uppdatera_objekt(id):
    data = läs_från_fil('data.json')
    nytt_data = request.json
    for index, o in enumerate(data):
        if o['id'] == id:
            data[index].update(nytt_data)
            skriv_till_fil('data.json', data)
            return data[index], 200
    return {"error": "Objekt hittades inte"}, 404

# Deleta ett objekt
@app.route('/<int:id>', methods=['DELETE'])
def radera_objekt(id):
    data = läs_från_fil('data.json')
    data = [o for o in data if o['id'] != id]
    skriv_till_fil('data.json', data)
    return {"message": "Objekt raderat"}, 200

if __name__ == '__main__':
    app.run(debug=True)
