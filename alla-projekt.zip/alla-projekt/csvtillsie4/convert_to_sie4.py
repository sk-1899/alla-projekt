import pandas as pd
import datetime
import os

def convert_csv_to_sie4(csv_path, sie_output_path):
    if not os.path.exists(csv_path):
        print(f"Fel: Filen {csv_path} finns inte.")
        return
    
    df = pd.read_csv(csv_path)
    df = df.drop_duplicates(subset=["Name"])
    df = df.dropna(subset=["Name", "Paid at", "Total", "Subtotal"])
    
    df["Paid at"] = pd.to_datetime(df["Paid at"], errors='coerce', utc=True)
    df["Paid at"] = df["Paid at"].dt.tz_localize(None)
    
    start_date = datetime.datetime(2024, 2, 16)
    end_date = datetime.datetime(2024, 12, 31)
    df = df[(df["Paid at"] >= start_date) & (df["Paid at"] <= end_date)]
    
    if df.empty:
        print("Fel: Ingen order matchar dataintervallet.")
        return
    
    accounting_year = "20250217"
    
    with open(sie_output_path, "w", encoding="utf-8") as f:
        f.write("#FLAGGA 0\n")
        f.write("#FORMAT PC8\n")
        f.write(f"#GEN {datetime.datetime.now().strftime('%Y%m%d')}\n")
        f.write("#SIETYP 4\n")
        f.write("#PROGRAM \"Visma eEkonomi\" \"Version 2024\"\n")
        f.write("#ORGNR 000000-0000\n")
        f.write("#KPTYP BAS2017\n")
        f.write("#FNAMN Företagsnamn\n")
        f.write(f"#RAR 20240101 20241231 0\n")
        
        ver_number = 1
        df = df.sort_values(by=["Paid at"])
        
        for _, row in df.iterrows():
            order_id = row["Name"]
            date = row["Paid at"].strftime('%Y%m%d')
            total = round(row["Total"], 2)
            subtotal = round(row["Subtotal"], 2)
            shipping = round(row.get("Shipping", 0) if not pd.isna(row.get("Shipping", 0)) else 0, 2)
            
            # Momsberäkning utifrån om subtotal inkluderar moms
            vat = round(subtotal * 25 / 125, 2)  # Korrekt momsberäkning
            taxable_amount = subtotal - vat  # Belopp exklusive moms
            
            total_credit = subtotal  # Subtotal bör redan inkludera moms
            diff = round(total - total_credit, 2)
            
            print(f"Debug: Order {order_id}: Total={total}, Subtotal={subtotal}, Shipping={shipping}, Taxable Amount={taxable_amount}, VAT={vat}, Total Credit={total_credit}, Diff={diff}")
            
            if abs(diff) >= 0.01:
                print(f"Varning: Order #{order_id} har en differens på {diff:.2f}. Kontrollera beloppen.")
            
            f.write(f"#VER A {ver_number} {date} \"Dagskassa\" {accounting_year}\n")
            f.write("{\n")
            f.write(f"#TRANS 3001 {{}} {-taxable_amount:.2f} \"\" \"Order {order_id}\" 0\n")
            f.write(f"#TRANS 2611 {{}} {-vat:.2f} \"\" \"Order {order_id}\" 0\n")
            if shipping > 0:
                f.write(f"#TRANS 3004 {{}} {-shipping:.2f} \"\" \"Frakt - Order {order_id}\" 0\n")
            f.write(f"#TRANS 1510 {{}} {total:.2f} \"\" \"Order {order_id}\" 0\n")
            f.write("}\n")
            
            ver_number += 1
    
    print(f"SIE4-fil skapad: {sie_output_path}")

csv_path = r"C:\\Users\\siver\\Desktop\\Converter\\input.csv"
sie_output_path = r"C:\\Users\\siver\\Desktop\\Converter\\output.se"
convert_csv_to_sie4(csv_path, sie_output_path)
